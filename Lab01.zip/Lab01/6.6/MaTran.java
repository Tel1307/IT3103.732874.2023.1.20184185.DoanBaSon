import java.util.Scanner;

public class MaTran {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int rows, columns;

        System.out.print("Nhap so hang: ");
        rows = scanner.nextInt();
        System.out.print("Nhap so cot: ");
        columns = scanner.nextInt();

        int[][] matrix1 = new int[rows][columns];
        int[][] matrix2 = new int[rows][columns];
        int[][] result = new int[rows][columns];

        System.out.println("Nhap cac phan tu cua ma tran thu nhat:");
        enterMatrixElements(matrix1, scanner);

        System.out.println("Nhap cac phan tu cua ma tran thu hai:");
        enterMatrixElements(matrix2, scanner);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        System.out.println("Tong cua hai ma tran:");
        printMatrix(result);
        scanner.close();
    }

    public static void enterMatrixElements(int[][] matrix, Scanner scanner) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                System.out.print("Nhap phan tu tai hang " + (i + 1) + ", cot " + (j + 1) + ": ");
                matrix[i][j] = scanner.nextInt();
            }
        }
    }

    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
