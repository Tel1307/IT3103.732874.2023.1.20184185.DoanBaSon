import java.util.Scanner;

public class PhuongTrinh {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Chon loai phuong trinh muon giai:");
        System.out.println("1. Phuong trinh bac nhat mot bien");
        System.out.println("2. He phuong trinh bac nhat hai bien");
        System.out.println("3. Phuong trinh bac hai mot bien");
        System.out.print("Nhap lua chon cua ban (1/2/3): ");
        int choice = scanner.nextInt();

        if (choice == 1) {
            giaiPhuongTrinhBacNhat(scanner);
        } else if (choice == 2) {
            giaiHePhuongTrinh(scanner);
        } else if (choice == 3) {
            giaiPhuongTrinhBacHai(scanner);
        } else {
            System.out.println("Lua chon khong hop le, vui long chon 1, 2 hoac 3.");
        }

        scanner.close();
    }

    public static void giaiPhuongTrinhBacNhat(Scanner scanner) {
        System.out.print("Nhap gia tri cua a: ");
        double a = scanner.nextDouble();
        System.out.print("Nhap gia tri cua b: ");
        double b = scanner.nextDouble();

        if (a == 0) {
            System.out.println("Phuong trinh khong hop le (a phai khac 0).");
        } else {
            double x = -b / a;
            System.out.println("Nghiem: x = " + x);
        }
    }

    public static void giaiHePhuongTrinh(Scanner scanner) {
        System.out.print("Nhap gia tri cua a11, a12, a21, a22, b1, b2: ");
        double a11 = scanner.nextDouble();
        double a12 = scanner.nextDouble();
        double a21 = scanner.nextDouble();
        double a22 = scanner.nextDouble();
        double b1 = scanner.nextDouble();
        double b2 = scanner.nextDouble();

        double D = a11 * a22 - a21 * a12;
        double D1 = b1 * a22 - b2 * a12;
        double D2 = a11 * b2 - a21 * b1;

        if (D == 0) {
            if (D1 == 0 && D2 == 0) {
                System.out.println("Vo so nghiem.");
            } else {
                System.out.println("Khong co nghiem.");
            }
        } else {
            double x1 = D1 / D;
            double x2 = D2 / D;
            System.out.println("Nghiem: x1 = " + x1 + ", x2 = " + x2);
        }
    }

    public static void giaiPhuongTrinhBacHai(Scanner scanner) {
        System.out.print("Nhap gia tri cua a, b, va c: ");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        double delta = b * b - 4 * a * c;

        if (a == 0) {
            System.out.println("Phuong trinh khong hop le (a phai khac 0).");
        } else if (delta < 0) {
            System.out.println("Khong co nghiem thuc.");
        } else if (delta == 0) {
            double x = -b / (2 * a);
            System.out.println("Nghiem kep: x = " + x);
        } else {
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
            System.out.println("Nghiem 1: x1 = " + x1);
            System.out.println("Nghiem 2: x2 = " + x2);
        }
    }
}
