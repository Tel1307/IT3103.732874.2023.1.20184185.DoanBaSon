import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhap phan tu dau tien: ");
        double num1 = scanner.nextDouble();

        System.out.print("Nhap phan tu thu hai: ");
        double num2 = scanner.nextDouble();

        if (num2 == 0) {
            System.out.println("Khong chia het cho 0");
        } else {
            double tong = num1 + num2;
            double hieu = num1 - num2;
            double tich = num1 * num2;
            double thuong = num1 / num2;

            System.out.println("Tong: " + tong);
            System.out.println("Hieu: " + hieu);
            System.out.println("Tich: " + tich);
            System.out.println("Thuong: " + thuong);
        }

        scanner.close();
    }
}
