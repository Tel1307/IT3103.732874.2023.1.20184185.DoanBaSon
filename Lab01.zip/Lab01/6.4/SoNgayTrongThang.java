import java.util.Scanner;

public class SoNgayTrongThang {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int nam;
        while (true) {
            System.out.print("Nhap nam: ");
            if (scanner.hasNextInt()) {
                nam = scanner.nextInt();
                if (nam >= 0) {
                    break;
                }
            }
            System.out.println("Khong hop le, hay thu lai.");
            scanner.nextLine();
        }

        String[] thang = {
            "Thang 1", "Thang 2", "Thang 3", "Thang 4", "Thang 5", "Thang 6", "Thang 7", "Thang 8", "Thang 9", "Thang 10", "Thang 11", "Thang 12",
            "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",
            "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "T11", "T12", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        };

        System.out.print("Nhap thang: ");
        String thangNhap = scanner.next();
        int viTriThang = -1;

        for (int i = 0; i < thang.length; i++) {
            if (thang[i].equalsIgnoreCase(thangNhap) ||
                thang[i].substring(0, 3).equalsIgnoreCase(thangNhap) ||
                String.valueOf(i % 12 + 1).equals(thangNhap)) {
                viTriThang = i;
                break;
            }
        }

        while (viTriThang == -1) {
            System.out.println("Khong hop le, hay thu lai.");
            System.out.print("Nhap thang: ");
            thangNhap = scanner.next();
            for (int i = 0; i < thang.length; i++) {
                if (thang[i].equalsIgnoreCase(thangNhap) ||
                    thang[i].substring(0, 3).equalsIgnoreCase(thangNhap) ||
                    String.valueOf(i % 12 + 1).equals(thangNhap)) {
                    viTriThang = i;
                    break;
                }
            }
        }

        boolean laNamNhuan = (nam % 4 == 0) && (nam % 100 != 0 || nam % 400 == 0);

        int[] soNgayTrongThang = laNamNhuan ?
            new int[] { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 } :
            new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        int soNgay = soNgayTrongThang[viTriThang % 12];
        String tenThang = thang[viTriThang];

        System.out.println("Trong nam " + nam + ", " + tenThang + " co " + soNgay + " ngay.");
    }
}
