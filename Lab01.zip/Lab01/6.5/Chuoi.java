1import java.util.Arrays;
import java.util.Scanner;

public class Chuoi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double[] numericArray;

        System.out.println("Chon mot lua chon:");
        System.out.println("1. Nhap mot chuoi tu ban phim");
        System.out.println("2. Su dung chuoi co san");
        System.out.print("Lua chon cua ban (1 hoac 2): ");
        int choice = scanner.nextInt();

        if (choice == 1) {
            System.out.print("Nhap so phan tu cua chuoi: ");
            int n = scanner.nextInt();
            numericArray = new double[n];

            System.out.println("Nhap cac phan tu cua chuoi:");
            for (int i = 0; i < n; i++) {
                numericArray[i] = scanner.nextDouble();
            }
        } else if (choice == 2) {
            numericArray = new double[]{1789, 2035, 1899, 1456, 2013};
        } else {
            System.out.println("Lua chon khong hop le, chon 1 hoac 2.");
            return;
        }

        Arrays.sort(numericArray);

        double sum = 0.0;
        for (double num : numericArray) {
            sum += num;
        }

        double average = sum / numericArray.length;

        System.out.println("Chuoi theo thu tu tang dan: " + Arrays.toString(numericArray));
        System.out.println("Tong cac phan tu: " + sum);
        System.out.println("Trung binh cong cac phan tu: " + average);

        scanner.close();
    }
}
